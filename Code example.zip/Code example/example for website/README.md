# ECE 140B - Individual Assignment1
**Tina Kafel - A14184808**

## Introduction

## Set up:

* Download Node.js (npm will automatically install)
* the file package.jspn includes the neceessary settings to run this website
* I have excluded the node modules from this repo; please run **npm start** to install the necessary node modules for this assignment
* I used the lite-server from the node modules for local run - information about the version can be found in package.json

* Install Bootstrap 4.0.0 using the command **npm install bootstrap@4.4.4 --save** 
* Bootstrap requires jQuery and popper.js. To install these packages run the command **npm install jquery@3.4.0 --save** and **npm install popper.js@1.12.9 --save** 
* Note the --save saves the information about the installed packages in the package.json for future use
* Include the following package as well: **npm install font-awesome@4.7.0 --save** Please note if you have addBlock installed, these fonts will not show
* install **npm install bootstrap-social@5.1.1 --save**
* to update any of these packages at anytime run **npm i -g npm** must have sudo preivilage first so do **sudo npm i -g npm**